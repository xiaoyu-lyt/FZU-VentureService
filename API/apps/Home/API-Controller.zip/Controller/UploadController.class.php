<?php
namespace Home\Controller;
use Home\Controller\BaseController;
class UploadController extends BaseController {

	/**
	 * 文件上传
	 * @return json
	 */
	public function fileUpload() {
		$login_user = session('login_user');

		$config = array(
			'maxSize'    =>    3145728,
		    'rootPath'   =>    './Uploads/',
		    'savePath'   =>    '',
		    'saveName'   =>    $login_user['uid'].'_'.time(),
		    // 'exts'       =>    array('jpg', 'gif', 'png', 'jpeg'),
		    'autoSub'    =>    true,
		    'subName'    =>    'Files/'.date('Ym',time()).'/'.date('d',time()),
			);
		$upload = new \Think\Upload($config);
		$info = $upload->upload();
		$info['url'] = "http://xx/FZU_VentureService/Uploads/".$info['file']["savepath"].$info['file']["savename"];
		if ($info) {
			$json = $this->jsonReturn(200,'文件上传成功',$info);
		} else {
			$json = $this->jsonReturn(0,'文件上传失败');
		}
		$this->ajaxReturn($json);
	}

	/**
	 * 头像上传
	 * @return json
	 */
	public function avatarUpload() {
		$login_user = session('login_user');

		$config = array(
			'maxSize'    =>    3145728,
		    'rootPath'   =>    './Uploads/',
		    'savePath'   =>    '',
		    'saveName'   =>    $login_user['uid'].'_'.time(),
		    'exts'       =>    array('jpg', 'gif', 'png', 'jpeg'),
		    'autoSub'    =>    true,
		    'subName'    =>    'Avatar/'.date('Ym',time()).'/'.date('d',time()),
			);
		$upload = new \Think\Upload($config);
		$info = $upload->upload();
		$info['url'] = "http://xx/FZU_VentureService/Uploads/".$info['file']["savepath"].$info['file']["savename"];
		if ($info) {
			$json = $this->jsonReturn(200,'头像上传成功',$info);
		} else {
			$json = $this->jsonReturn(0,'头像上传失败');
		}
		$this->ajaxReturn($json);
	}
}